using InventoryManagement.DataAccess;
using InventoryManagement.Service;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace InventoryUnitTest
{
    [TestClass]
    public class InventoryServiceTest
    {
        [TestMethod]
        public void Get_Inventory_With_Wrong_Product()
        {
            string productId = "101";
            int quantity = 1;

            IRepository repository = new DAInventory();
            IInventory service = new InventoryService(repository);

            var result=service.CheckInventory(productId, quantity);

            Assert.IsFalse(result, "Test Pass");
        }
        [TestMethod]
        public void Get_Inventory_With_Correct_Product()
        {
            string productId = "P001";
            int quantity = 1;

            IRepository repository = new DAInventory();
            IInventory service = new InventoryService(repository);

            var result = service.CheckInventory(productId, quantity);

            Assert.IsTrue(result, "Test Pass");
        }
        [TestMethod]
        public void Get_Inventory_With_InSufficientQuntity()
        {
            string productId = "P001";
            int quantity = 11;

            IRepository repository = new DAInventory();
            IInventory service = new InventoryService(repository);

            var result = service.CheckInventory(productId, quantity);

            Assert.IsFalse(result, "Test Pass");
        }
        [TestMethod]
        public void Get_Inventory_With_Available_Quntity()
        {
            string productId = "P001";
            int quantity = 1;

            IRepository repository = new DAInventory();
            IInventory service = new InventoryService(repository);

            var result = service.CheckInventory(productId, quantity);

            Assert.IsTrue(result, "Test Pass");
        }
    }
}
