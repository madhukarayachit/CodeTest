﻿using System;
namespace InventoryManagement.Utility
{
    public class EmailHelper
    {
        public static void SendEmail(string to, string from ,string message)
        {
            Console.WriteLine("Email Sent !!!");
        }
    }
}
