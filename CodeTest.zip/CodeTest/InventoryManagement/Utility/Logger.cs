﻿using System;
namespace InventoryManagement.Utility
{
    public class Logger
    {
        public static void  LogError(string errorMessage)
        {
            Console.WriteLine(errorMessage);
        }
    }
}
