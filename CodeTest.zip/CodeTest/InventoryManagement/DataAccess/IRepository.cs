﻿using System;
namespace InventoryManagement.DataAccess
{
    public interface IRepository
    {
        bool CheckInventory(string productId, int qty);
    }
}
