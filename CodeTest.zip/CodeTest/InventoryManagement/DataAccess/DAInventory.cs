﻿using System;
using System.Collections.Generic;
using System.Linq;
using InventoryManagement.Model;

namespace InventoryManagement.DataAccess
{
    public class DAInventory :IRepository
    {
        public DAInventory()
        {

        }

        public bool CheckInventory(string productId, int qty)
        {
            // We can also throw exception agaisnt each of the invalid input
            // deliberately avoiding exception handling
            // exceptions are bubbled (if any)
            var Inventory=GetInventory().Where(inv => inv.ProductID == productId && inv.Quantity >=qty);
            if (Inventory == null || Inventory.Count() == 0)
            {
                return false;
            }
            return true;

        }
        private List<Inventory> GetInventory()
        {
            // We can use Concrete implementation of DA  
            var inventories = new List< Inventory >
                                    {
                                        new Inventory { InventoryID=1,ProductID="P001",Quantity=10 },
                                        new Inventory { InventoryID=2,ProductID="P002",Quantity=10 },
                                        new Inventory { InventoryID=3,ProductID="P003",Quantity=10 },

                                    };
            return inventories;
        }
    }
}
