﻿using System;
namespace InventoryManagement.Model
{
    public class Product
    {
        public string ProductId { get; set; }
        public string ProductName { get; set; }
    }
}
