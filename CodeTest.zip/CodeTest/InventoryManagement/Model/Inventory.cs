﻿using System;
namespace InventoryManagement.Model
{
    public class Inventory
    {
        public int InventoryID { get; set; }
        public string ProductID { get; set; }
        public int Quantity { get; set; }
    }
}
