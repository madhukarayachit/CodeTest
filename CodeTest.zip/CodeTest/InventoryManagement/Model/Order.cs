﻿using System;
namespace InventoryManagement.Model
{
    public class Order
    {
        public int OrderId { get; set; }
        public int OrderQuantity { get; set; }
    }
}
