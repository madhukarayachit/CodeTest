﻿using System;
using InventoryManagement.DataAccess;

namespace InventoryManagement.Service
{
    public class InventoryService : IInventory
    {
        private readonly IRepository inventory;

        public InventoryService(DataAccess.IRepository inventory)
        {
            this.inventory = inventory;
        }

        public bool CheckInventory(string productId, int qty)
        {
            //Can apply validation for valid product & quantity
          
            //  We can capture and log possible exceptions here

            return inventory.CheckInventory(productId, qty);
        }
    }
}
