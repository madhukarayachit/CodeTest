﻿using System;
namespace InventoryManagement.Service
{
    interface IPaymentService
    {
        bool ChargePayment(string creditCardNumber, decimal amount);
    }
    public class PaymentService
    {
        public bool ChargePayment(string creditCardNumber, decimal amount)
        {
            //mimics 3rd Party service which should
            //take care of CC# validations
            return true;
        }
    }
}
