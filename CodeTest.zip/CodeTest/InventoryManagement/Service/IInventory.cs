﻿using System;
namespace InventoryManagement.Service
{
    public interface IInventory
    {
        bool CheckInventory(string productId, int qty);
    }
}
