﻿using System;
using System.Configuration;
using InventoryManagement.DataAccess;
using InventoryManagement.Model;
using InventoryManagement.Service;
using InventoryManagement.Utility;
namespace InventoryManagement
{
    class MainClass
    {
      

        public static void Main(string[] args)
        {
            var inventory = new Inventory();
            inventory.ProductID = "P001";
            inventory.Quantity = 5;
            IRepository daInventory = new DAInventory();

            try
            {

                // We can use any DI framework to inject  Data Access Obkect into service

                InventoryService service = new InventoryService(daInventory);

                var IsAvailable = service.CheckInventory(inventory.ProductID, inventory.Quantity);

                if (IsAvailable)
                {
                    var paymentService = new PaymentService();

                    //using dummy values
                    string ccNumber = "4444111122224444";
                    decimal amount = 5000;


                    var success = paymentService.ChargePayment(ccNumber, amount);

                    if (success)
                    {
                        Console.WriteLine("Payment has been made successfully...");

                        SendNotificationEmail();
                    }
                    else
                    {
                        Console.WriteLine("Payment transaction fiealed!!!");
                    }

                }
                else
                {
                    Console.WriteLine("Insufficient Inventory");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error !!! ");

                // Log exceptions
                // using a dumy logger 
                Logger.LogError(ex.StackTrace);
            }
        }

        private static void SendNotificationEmail()
        {
            //pull desired email addresses and message from config
            string msg = ConfigurationManager.AppSettings["Message"].ToString();
            string from = ConfigurationManager.AppSettings["From"].ToString();
            string to = ConfigurationManager.AppSettings["To"].ToString();

            EmailHelper.SendEmail(to, from, msg);
        }
    }
}
